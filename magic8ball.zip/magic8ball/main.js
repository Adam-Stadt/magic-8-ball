// Element Variables
let eightButtonEl = document.getElementById("magic8ball");
let outputEl = document.getElementById("text-output");
let inputEl = document.getElementById("question-input");
// I don't really need these, as I only use each element once anyway - but I use them to make the code more legible.

// Event Listener
eightButtonEl.addEventListener("click", answerQuestion);

function answerQuestion() {
    // Input
    let question = inputEl.value;
    let answer;

    // Process
    if (question === "Does a magic 8 ball actually work?") {
        answer = "How dare you doubt me!";
    } else if (question === "Is JavaScript awesome?") {
        answer = "Of Course!";
    } else if (question === "E?") {
        answer = "E.";
    } else if (question === "Who's Joe?" || question === "Who is Joe?") {
        answer = "JOE MAMA";
    } else if (question === "") {
        answer = "Please ask a question..."
    } else {
        let randNum = Math.random();
        if (randNum < 0.2) {
            answer = "Without a Doubt.";
        } else if (randNum < 0.4) {
            answer = "As I see it, yes.";
        } else if (randNum < 0.6) {
            answer = "Concentrate and ask again.";
        } else if (randNum < 0.8) {
            answer = "Don't count on it.";
        } else {
            answer = "Outlook not so good.";
        }
    }

    // Output
    outputEl.innerHTML = answer;
}